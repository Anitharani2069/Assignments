package collectionexamples;

import java.util.Date;

public class ThreadExampleUsingRunnable implements Runnable{

	@Override
	public void run() {
		Date date=new Date();
		while(true)
		{
			System.out.println(date);
			try
			{
				System.out.println("Current thread name is:"+Thread.currentThread().getName());
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}
	

}
