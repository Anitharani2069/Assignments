package collectionexamples;

import java.util.Scanner;

public class ProducerConsumerMain {

	public static void main(String[] args) throws InterruptedException {
	
		ProducerConsumer producerConsumer=new ProducerConsumer();
		Thread thread=new Thread(new Runnable(){
				public void run()
				{
				try{
			producerConsumer.producer();
			}
		catch(Exception e)
		{
		e.printStackTrace();
		}}});
		Thread thread1=new Thread(new Runnable(){
			public void run()
			{
			try{
		producerConsumer.consumer();
		}
	catch(Exception e)
	{
	e.printStackTrace();
	}}});
		thread.start();
		thread1.start();
		
		thread.join();
		thread.join();

	}

}
