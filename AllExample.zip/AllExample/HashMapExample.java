package collectionexamples;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class HashMapExample {

	public static void main(String[] args) {
		HashMap<Integer,Question1> map=new HashMap<Integer,Question1>();
		Question1 obj=new Question1(5,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(1,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		map.put(obj.getCustomerId(), obj);
		map.put(obj1.getCustomerId(),obj1);
		map.put(obj2.getCustomerId(),obj2);
		//System.out.println(map);
		
		Scanner sc=new Scanner(System.in);
		int customerId=sc.nextInt();
		
		if(map.containsKey(customerId))
		{
			System.out.println(map.get(customerId));
		}
		
				map.remove(customerId);
			
		System.out.println(map);
		
		
		

	}

}
