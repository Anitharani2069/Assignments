package collectionexamples;

import java.util.Hashtable;
import java.util.Scanner;

public class HashTableExample {

	public static void main(String[] args) {

		Hashtable<Integer, Question1> hashtable=new Hashtable<Integer,Question1>();
		Question1 obj=new Question1(5,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(1,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		
		hashtable.put(obj.getCustomerId(), obj);
		hashtable.put(obj1.getCustomerId(), obj1);
		hashtable.put(obj2.getCustomerId(), obj2);
		
		Scanner scanner=new Scanner(System.in);
		int id=scanner.nextInt();
		if(hashtable.containsKey(id))
			System.out.println(hashtable.get(id));
		

	}

}
