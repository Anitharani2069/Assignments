package collectionexamples;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashMapKey {
	public static void main(String args[])
	{
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(1, "supriya");
		map.put(3, "snehal");
		map.put(2, "jyoti");
		System.out.println(map);
		Scanner scanner=new Scanner(System.in);
		int id=scanner.nextInt();
		if(map.containsKey(id))
		{
			System.out.println(map.get(id));
		}
		else
		{
			System.out.println("key is not available");
		}
	}

}
