package collectionexamples;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ThreadPriority {

	public void thread1() 
	{
		String str1="Hello";
		
		String str2="there";
		try
		{
			System.out.println("Thread 1:"+Thread.currentThread().getPriority());

			System.out.println(str1);
			Thread.sleep(1000);
			System.out.println(str2);


		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void thread2() 
	{
		String str1="how are";
		String str2="you";
		try
		{
			System.out.println("Thread 2:"+Thread.currentThread().getPriority());

			System.out.println(str1);

			Thread.sleep(1000);
			System.out.println(str2);
			//System.out.println("Thread 2:"+Thread.currentThread().getPriority());


		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void thread3() 
	{
		String str1="Thank you";
		
		String str2="Very much";
		try
		{
			System.out.println("Thread 3:"+Thread.currentThread().getPriority());

			System.out.println(str1);

			Thread.sleep(1000);
			System.out.println(str2);
			//System.out.println("Thread 3:"+Thread.currentThread().getPriority());

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String args[])
	{
		ThreadPriority threadPriority=new ThreadPriority();
		Executor executor=Executors.newFixedThreadPool(3);
		Runnable task=()->threadPriority.thread1();
		executor.execute(task);
		Runnable task1=()->threadPriority.thread2();
		executor.execute(task1);
		Runnable task3=()->threadPriority.thread3();
		executor.execute(task3);
		
	}
	
}
