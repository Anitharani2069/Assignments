package collectionexamples;

import java.util.Date;

public class ExampleOfThreadUsingExtendingThread extends Thread{
	public void run()
	{
		Date date=new Date();
		while(true)
		{
			System.out.println(date);
			try{
		        System.out.println("Current Thread Name- " + Thread.currentThread().getName());
		        Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}

