package collectionexamples;

import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ThreadExampleUsingExecutor {
	public void exampleExecutot()
	{
		Date date=new Date();
		while(true)
		{
			System.out.println(date);
			try
			{
				System.out.println("Current thread::"+Thread.currentThread().getName());
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	public static void main(String args[])
	{
		ThreadExampleUsingExecutor threadExampleUsingExecutor=new ThreadExampleUsingExecutor();
		Executor executor=Executors.newFixedThreadPool(3);
		Runnable task=()->threadExampleUsingExecutor.exampleExecutot();
		executor.execute(task);
		Runnable task1=()->threadExampleUsingExecutor.exampleExecutot();
		executor.execute(task1);
		Runnable task2=()->threadExampleUsingExecutor.exampleExecutot();
		executor.execute(task2);


	}

}
