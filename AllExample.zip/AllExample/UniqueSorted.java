package collectionexamples;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class UniqueSorted {
	public static void main(String args[])
	{
		Set<Question1> set=new TreeSet<Question1>();
		Question1 obj=new Question1(1,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(3,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		set.add(obj);
		set.add(obj1);
		set.add(obj2);
		List<Question1>set1=new ArrayList<>(set);

		
		Scanner scanner=new Scanner(System.in);
		int id=scanner.nextInt();
		//Question1 question1=set.
		for(int i=0;i<set1.size();i++)
		{
			Question1 question1=set1.get(i);
			
				if(question1.getCustomerId()==id)
				{
					set1.remove(question1)	;
				}
			
		}
		
		//System.out.println("customer object removed");
		//System.out.println(set1);
		Iterator itr=set1.iterator();
		while(itr.hasNext())
		{
			
			System.out.println(itr.next());
		}
		
		
		
		
		
	}
}
