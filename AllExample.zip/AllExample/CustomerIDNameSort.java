package collectionexamples;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;


public class CustomerIDNameSort {
	public static void main(String args[])
	{
		Set<Question2> set=new HashSet<Question2>();
		ArrayList<Question2> set1=new ArrayList<>(set);
		Question2 obj=new Question2(5,"supriya","Ichalkaranji");
		Question2 obj1=new Question2(1,"snehal","Koprochi");
		Question2 obj2=new Question2(2,"priti","sangli");
		set1.add(obj);
		set1.add(obj1);
		set1.add(obj2);
		Collections.sort(set1);
		System.out.println(set1);
		
	}

}
