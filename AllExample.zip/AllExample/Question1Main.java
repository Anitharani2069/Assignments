package collectionexamples;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Question1Main {

	public static void main(String[] args) {
		Set<Question1> set=new TreeSet<Question1>();
		Question1 obj=new Question1(5,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(1,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		set.add(obj);
		set.add(obj1);
		set.add(obj2);
		Iterator itr=set.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}

}
