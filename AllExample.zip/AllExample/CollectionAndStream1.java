package collectionexamples;
enum Gender
{
		MALE,FEMALE,OTHER
}
public class CollectionAndStream1 {
	private String name;
	Gender gender;
	@Override
	public String toString() {
		return "CollectionAndStream1 [name=" + name + ", gender=" + gender + "]";
	}
	public CollectionAndStream1(String name, Gender gender) {
		super();
		this.name = name;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}

}
