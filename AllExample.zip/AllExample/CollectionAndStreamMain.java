package collectionexamples;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.DoubleStream;
//import java.util.stream.Stream;
import java.util.stream.Stream;

public class CollectionAndStreamMain {
	public static void main(String args[])
	{
	List<CollectionAndStream1> list=new ArrayList<CollectionAndStream1>();
	CollectionAndStream1 obj=new CollectionAndStream1("supriya",Gender.FEMALE);
	CollectionAndStream1 obj1=new CollectionAndStream1("dhjf",Gender.MALE);
	CollectionAndStream1 obj2=new CollectionAndStream1("iotuo",Gender.FEMALE);
	CollectionAndStream1 obj3=new CollectionAndStream1("gyuit",Gender.MALE);
	list.add(obj);
	list.add(obj1);
	list.add(obj2);
	list.add(obj3);

	
	Stream<CollectionAndStream1> stream=list.stream();
	Stream<CollectionAndStream1> stream1=stream.filter((CollectionAndStream1)->CollectionAndStream1.getGender().equals(Gender.FEMALE));
	Stream<Object> stream2=stream1.map((CollectionAndStream1)->CollectionAndStream1.getName().toUpperCase());
	// doubleStream = stream.mapToDouble(x -> x);
	
	stream2.forEach(System.out::println);
	//stream1.forEach((msg)->System.out.println(msg));
	}
	
}
