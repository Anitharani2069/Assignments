package collectionexamples;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class HashTableWithDuplicates {

	public static void main(String[] args) {

		Hashtable<Integer, Question1> hashtable=new Hashtable<Integer,Question1>();
		Question1 obj=new Question1(5,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(1,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		Question1 obj3=new Question1(2,"jyoti","sangli");

		
		hashtable.put(obj.getCustomerId(), obj);
		hashtable.put(obj1.getCustomerId(), obj1);
		hashtable.put(obj2.getCustomerId(), obj2);
		hashtable.put(obj3.getCustomerId(), obj3);

		Scanner scanner=new Scanner(System.in);
		int id=scanner.nextInt();
		

				hashtable.remove(id);
	
		for(int i=0;i<hashtable.size();i++)
		{
			System.out.println(hashtable);

		}
	}

}
