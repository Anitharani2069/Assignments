package collectionexamples;

public class ThreadExampleUsingRunnableMain {

	public static void main(String[] args) {

		Runnable runnable=new ThreadExampleUsingRunnable();
		Thread thread=new Thread(runnable,"Thread 1");
		Thread thread1=new Thread(runnable,"Thread 2");
		Thread thread2=new Thread(runnable,"Thread 3");

		thread.start();
		thread1.start();
		thread2.start();
		
	}

}
