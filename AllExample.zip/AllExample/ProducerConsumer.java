package collectionexamples;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class ProducerConsumer extends Thread{
	LinkedList<Integer>list=new LinkedList<Integer>();
	Scanner scanner=new Scanner(System.in);
	public void producer() throws InterruptedException
	{
		int value=0;
		 while (true) 
         { 
             synchronized (this) 
             { 
              
		if(list.size()==5)
			Thread.sleep(5000);
		else
			list.add(value++);
             }	
         }
	}

	public void consumer() throws InterruptedException
	{
		while (true) 
        { 
            synchronized (this) 
            { 
             
            	while(list.size()==-1)
            	{
			Thread.sleep(10000);
            	}
        
            	int val = list.removeFirst(); 
            	System.out.println(val);
            }
            }
	}
}
	


