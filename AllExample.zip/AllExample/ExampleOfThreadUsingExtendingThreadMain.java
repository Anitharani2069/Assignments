package collectionexamples;

public class ExampleOfThreadUsingExtendingThreadMain {
	public static void main(String args[])
	{
		
		ExampleOfThreadUsingExtendingThread exampleOfThreadUsingExtendingThread=new ExampleOfThreadUsingExtendingThread();
		Thread thread=new Thread(exampleOfThreadUsingExtendingThread,"Thread 1");
		Thread thread1=new Thread(exampleOfThreadUsingExtendingThread,"Thread 2");
		Thread thread2=new Thread(exampleOfThreadUsingExtendingThread,"Thread 3");

		
		thread.start();
		thread1.start();
		thread2.start();
		
	}

}
