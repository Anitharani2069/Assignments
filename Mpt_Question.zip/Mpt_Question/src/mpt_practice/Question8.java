package mpt_practice;
import java.util.*;

class Customer8 {
	String name;
	int id;
	public Customer8() {
		super();
	}
	public Customer8(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Customer8 [name=" + name + ", id=" + id + "]";
	}
}
public class Question8 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Vector<Customer8> v=new Vector<Customer8>();
		int choice=0;
		while(choice!=3) {
			System.out.println("1.enter data\n2.remove data\n3.exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("how many data wants to enter");
				int entry=scanner.nextInt();
				for(int i=1;i<=entry;i++) {
					System.out.println("enter the id");
					int id=scanner.nextInt();
					System.out.println("enter the name");
					String name=scanner.next();
					Customer8 c=new Customer8(name,id);
					v.add(c);
				}
				System.out.println(v);
				break;
			case 2:
				System.out.println("enter the id to remove");
				int k=scanner.nextInt();
				for(Customer8 removec:v) {
					if(removec.getId()==k)
						v.remove(removec);
				}
				System.out.println(v);
			case 3:
				System.exit(0);
			}
		}

	}

}
