package mpt_practice;
import java.util.*;

class Customer6 {
	int id;
	String name;
	public Customer6() {
		super();
	}
	public Customer6(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Customer6 [id=" + id + ", name=" + name + "]";
	}
	
}

public class Question6 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Map<Integer,String> hm=new HashMap<Integer,String>();
		int choice=0;
		while(choice!=3) {
			System.out.println("1.enter data\n2.retrieve data\n3.exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("how many data wants to enter");
				int entry=scanner.nextInt();
				for(int i=1;i<=entry;i++) {
					System.out.println("enter the id");
					int id=scanner.nextInt();
					System.out.println("enter the name");
					String name=scanner.next();
					Customer6 c=new Customer6(id,name);
					hm.put(c.id,c.name);
				}
				break;
			case 2:
				System.out.println("enter the key");
				int k=scanner.nextInt();
				if(hm.containsKey(k))
					System.out.println(hm.get(k));
				else
					System.out.println("key not available");
				break;
			case 3:
				System.exit(0);
			}
		}
		

	}

}
