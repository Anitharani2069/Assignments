package mpt_practice;
import java.util.*;

class CustomerUnique implements Comparable<CustomerUnique> {
	String name;
	int id;
	
	public CustomerUnique(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "CustomerUnique [name=" + name + ", id=" + id + "]";
	}
	@Override
	public int compareTo(CustomerUnique c) {
		if(this.id>c.id)
			return 1;
		else
			return -1;
	
	}
	
}

//class CompareId implements Comparator<CustomerUnique> {
//
//	@Override
//	public int compare(CustomerUnique c1, CustomerUnique c2) {
//		
//	}
//	
//}
public class Question4 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Set<CustomerUnique> ts=new HashSet<CustomerUnique>();
		CustomerUnique cust;
		int choice=0;
		while(choice!=3) {
			System.out.println("1.enter customer details\n2.remove customer details\n3.all details\n4.exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("how many entries u want");
				int entry=scanner.nextInt();
				for(int i=1;i<=entry;i++) {
					System.out.println("enter the customer name");
					String name=scanner.next();
					System.out.println("enter the customer id");
					int id=scanner.nextInt();
					 cust=new CustomerUnique(name,id);
					ts.add(cust);
				}
				System.out.println(ts);
				break;
			case 2:
				System.out.println("enter the id to remove details");
				int id=scanner.nextInt();
				for(CustomerUnique cu :ts) {
					
					if(cu.getId()==id) {
						//CustomerUnique newcust=cu;
						System.out.println(cu);
						ts.remove(cu);
						System.out.println("details removed");
						break;
					}
					//else
						//System.out.println("data not found");
				}
				System.out.println("ts"+ts);
				break;
			case 3:
				System.out.println("all customers details");
				Iterator itr=ts.iterator();
				while(itr.hasNext()) {
					System.out.println(itr.next());
				}
			case 4:
				System.exit(0);
			}
		}
		
	}

}
