package mpt_practice;
import java.util.*;

class CustomerDetails {
	int customerId;
	String cutomerName;
	long customermobileNo;
	String customerCity;
	public CustomerDetails() {
		super();
	}
	public CustomerDetails(int customerId, String cutomerName, long customermobileNo, String customerCity) {
		super();
		this.customerId = customerId;
		this.cutomerName = cutomerName;
		this.customermobileNo = customermobileNo;
		this.customerCity = customerCity;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCutomerName() {
		return cutomerName;
	}
	public void setCutomerName(String cutomerName) {
		this.cutomerName = cutomerName;
	}
	public long getCustomermobileNo() {
		return customermobileNo;
	}
	public void setCustomermobileNo(long customermobileNo) {
		this.customermobileNo = customermobileNo;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	@Override
	public String toString() {
		return "CustomerDetails [customerId=" + customerId + ", cutomerName=" + cutomerName + ", customermobileNo="
				+ customermobileNo + ", customerCity=" + customerCity + "]";
	}
	
	
}
public class Question3 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Map<Integer,CustomerDetails> hm=new HashMap<Integer,CustomerDetails>();
		int choice=0;
		while(choice!=3) {
			System.out.println("1.create customer objects\n2.retrieve customer details\n3.exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("how many entries do u want");
				int entry=scanner.nextInt();
				for(int i=1;i<=entry;i++) {
					System.out.println("enter the customer id");
					int id=scanner.nextInt();
					System.out.println("enter the customer name");
					String name=scanner.next();
					System.out.println("enter the customer mobileNo");
					long mobile=scanner.nextLong();
					System.out.println("enter the customer city");
					String city=scanner.next();
					CustomerDetails cd=new CustomerDetails(id,name,mobile,city);
					hm.put(cd.getCustomerId(),cd);
				}
				break;
			case 2:
				System.out.println("enter the customer Id");
				int cid=scanner.nextInt();
				CustomerDetails cd1=hm.get(cid);
				System.out.println(cd1);
				break;
			case 3:
				System.exit(0);
			}
		}

	}

}
