package mpt_practice;
import java.util.*;

class CustomerData implements Comparable<CustomerData> {
	String name;
	long mobileNumber;
	int id;
	String address;
	public CustomerData() {
		super();
	}
	
	public CustomerData(String name, long mobileNumber, int id, String address) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.id = id;
		this.address = address;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "CustomerData [name=" + name + ", mobileNumber=" + mobileNumber + ", id=" + id + ", address=" + address
				+ "]";
	}

	@Override
	public int compareTo(CustomerData c) {
		if(this.id>c.id) 
			return 1;
		else
			return -1;
	}
}

class CompareName implements Comparator<CustomerData> {

	@Override
	public int compare(CustomerData c1, CustomerData c2) {
		return c1.getName().compareTo(c2.getName());
	}
	
}

public class Question2 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Set<CustomerData> treeset=new TreeSet<CustomerData>(new CompareName());
		Set<CustomerData> treeset1=new TreeSet<CustomerData>();
		System.out.println("how many details want to store");
		int total=scanner.nextInt();
		for(int i=1;i<=total;i++) {
			System.out.println("enter customer name");
			String name=scanner.next();
			System.out.println("enter customer mobile number");
			long mobileno=scanner.nextLong();
			System.out.println("enter customer id");
			int id=scanner.nextInt();
			System.out.println("enter the customer address");
			String address=scanner.next();
			CustomerData customer=new CustomerData(name,mobileno,id,address);
			treeset.add(customer);
			treeset1.add(customer);
		}
		System.out.println("By Name");
		Iterator itr=treeset.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		System.out.println("By Id");
		Iterator itr1=treeset1.iterator();
		while(itr1.hasNext()) {
			System.out.println(itr1.next());
		}

	}

}
