package mpt_practice;
import java.util.*;

public class Question15 {

	public static void main(String[] args) {
		

	}

}
