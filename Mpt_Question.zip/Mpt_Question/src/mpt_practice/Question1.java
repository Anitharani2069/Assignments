package mpt_practice;
import java.util.*;

class Customer implements Comparable {
	String name;
	long mobileNumber;
	String address;
	public Customer() {
		super();
	}
	public Customer(String name, long mobileNumber, String address) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNumber=" + mobileNumber + ", address=" + address + "]";
	}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
//	public String comapreTo(Customer c1,Customer c2) {
//		if(c1.getName().indexOf(0)>c2.getName().indexOf(0)) {
//			return c2.getName();
//		}
//		else
//			return name;
//			
//		
//	}
}
class NameCompare implements Comparator<Customer> {

	@Override
	public int compare(Customer c1, Customer c2) {
		// TODO Auto-generated method stub
		return c1.getName().compareTo(c2.getName());
	}
	
}


public class Question1 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Set<Customer> treeset=new TreeSet<Customer>(new NameCompare());
		System.out.println("how many details want to store");
		int total=scanner.nextInt();
		for(int i=1;i<=total;i++) {
			System.out.println("enter customer name");
			String name=scanner.next();
			System.out.println("enter customer mobile number");
			long mobileno=scanner.nextLong();
			System.out.println("enter the customer address");
			String address=scanner.next();
			Customer customer=new Customer(name,mobileno,address);
			treeset.add(customer);
		}
		
		Iterator itr=treeset.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
