package mpt_practice;
import java.util.*;

class Customer7 {
	String name;
	int id;
	public Customer7() {
		super();
	}
	public Customer7(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Customer7 [name=" + name + ", id=" + id + "]";
	}
}

public class Question7 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Hashtable<Integer,Customer7> ht=new Hashtable<Integer,Customer7>();
		int choice=0;
		while(choice!=3) {
			System.out.println("1.enter data\n2.retrieve data\n3.exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("how many data wants to enter");
				int entry=scanner.nextInt();
				for(int i=1;i<=entry;i++) {
					System.out.println("enter the id");
					int id=scanner.nextInt();
					System.out.println("enter the name");
					String name=scanner.next();
					Customer7 c=new Customer7(name,id);
					ht.put(c.id,c);
				}
				break;
			case 2:
				System.out.println("enter the id ");
				int id=scanner.nextInt();
				Customer7 rc=ht.get(id);
				System.out.println(rc);
				break;
			case 3:
				System.exit(0);
			}
		}
	}

}
