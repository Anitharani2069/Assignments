package mpt_practice;
import java.util.*;

public class Question47 {
	public static void main(String[] args) {
		CustomerUnique c=new CustomerUnique("shubham",47);
		CustomerUnique c1=new CustomerUnique("suro",48);
		Set<CustomerUnique> hs=new HashSet<CustomerUnique>();
		hs.add(c);
		hs.add(c1);
		System.out.println(hs);
		CustomerUnique c2=c1;
		hs.remove(c2);
		System.out.println(hs);
	}

}
