package mpt_practice;
import java.util.*;

class Customer9 {
	String name;
	int id;
	public Customer9() {
		super();
	}
	public Customer9(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Customer9 [name=" + name + ", id=" + id + "]";
	}
}

public class Question9 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		List<Customer9> al=new LinkedList<Customer9>();
		int choice=0;
		while(choice!=3) {
			System.out.println("1.enter data\n2.insert data\n3.exit");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("how many data wants to enter");
				int entry=scanner.nextInt();
				for(int i=1;i<=entry;i++) {
					System.out.println("enter the id");
					int id=scanner.nextInt();
					System.out.println("enter the name");
					String name=scanner.next();
					Customer9 c=new Customer9(name,id);
					al.add(c);
				}
				break;
			case 2:
				System.out.println("enter the position");
				int l=scanner.nextInt();
				System.out.println("enter the name");
				String nname=scanner.next();
				System.out.println("enter the id");
				int ni=scanner.nextInt();
				Customer9 nc=new Customer9(nname,ni);
				al.add(l-1,nc);
				System.out.println(al.get(2));
				break;
			case 3:
				System.exit(0);
			}
		}
	}
}
