package lab8;

import java.time.*;
import java.util.Date;

public class Ex6 {
	void setdate(Date d)
	{
		System.out.println();
	}
public static void main(String args[])
{
	LocalDate now=LocalDate.now();
	System.out.println("Time" + " "+now);
}
}
