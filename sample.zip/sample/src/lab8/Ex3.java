package lab8;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Ex3 {
	public static void main(String[] args)
	{
		int charCount=0;
		int lineCount=0;
		int wordCount=0;
		String line=null;
		String st;
		Scanner sc=new Scanner(System.in);
		st=sc.nextLine();
		try
		{
			FileReader fileReader=new java.io.FileReader(st);
			BufferedReader bufferedReader=new BufferedReader(fileReader);
			while((line=bufferedReader.readLine())!=null)
			{
				    charCount+=line.length();
					String[] word=line.split("\\s+ ");
					wordCount=wordCount+word.length;
					String[] sentence=line.split("[!?.:]+ ");
					lineCount+=sentence.length;
					
			}
			bufferedReader.close();
			System.out.println("Characters are "+charCount);
			System.out.println("Words are  "+wordCount);
			System.out.println("No of lines are "+lineCount);
			
		}catch(IOException e)
		{
			System.out.println("Exception error");
			
		}
		sc.close();
		
		
	}

}
