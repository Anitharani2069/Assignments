package lab10;
import java.util.Date;
public class Ex2 implements Runnable {
	Thread t=new Thread(this);
	public Ex2() throws InterruptedException{
          t=new Thread(this);
          t.start();
	}
	@Override
	public void run()
	{
		Date date;
		while(true) 
		{
			try {
				date=new Date();
				Thread.sleep(3000);
				System.out.println(date.getHours()+":"+date.getMinutes()+":"+date.getSeconds());
				
			}catch (InterruptedException e)
			{
				System.out.println("Exception error");
			}
		}
	}
	public static void main(String args[]) throws InterruptedException {
		Ex2 obj=new Ex2();
	}

}
