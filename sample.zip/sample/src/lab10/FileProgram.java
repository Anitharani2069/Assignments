package lab10;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class FileProgram {
	public static void main(String args[]) throws IOException 
	{
     try {
    	 FileInputStream fisObj=new FileInputStream("c:\\Users\\ygudala\\Documents\\source.txt");
    	 FileOutputStream fosObj=new FileOutputStream("c:\\Users\\ygudala\\Documents\\target.txt");
    	 CopyDataThread ctd=new CopyDataThread(fisObj,fosObj);
    	 ctd.start();
     }catch(Exception e)
     {
    	 System.out.println(e);
     }
	}
}
