package lab9;
import java.util.Scanner;
import java.util.Set;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
class Map
{
	int id;
	String name;
	Map(int idd, String n)
	{
		id=idd;
		name=n;
	}
	public String toString()
	{
		return ("id: " +id +" & name: "+name);
			
	}
}
public class Ex1 {
	ArrayList getValues(HashMap m)
	{
		Collection values=m.values();
		ArrayList li=new ArrayList(values);
		Set s=m.keySet();
		Iterator it=s.iterator();
		return li;
	}
    public static void main(String[] args)
    {
         Scanner sc=new Scanner(System.in);
         Ex1 obj=new Ex1();
         Map obj1=new Map(18,"VIRAT");
         Map obj2=new Map(7,"DHONI");
         HashMap<Integer,Map> hm=new HashMap<Integer,Map>();
         hm.put(1,obj1);
         hm.put(2,obj2);
         System.out.println(obj.getValues(hm));
         sc.close();
    }
}
 