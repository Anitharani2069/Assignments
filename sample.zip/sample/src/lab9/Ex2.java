package lab9;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Ex2 {
  HashMap countCharacter(char[] ch)
  {
	  HashMap<Character, Integer> hm=new HashMap<Character, Integer>();
	int l=ch.length;
	int count=0,flag=0;
	for(int i=0;i<l;i++)
	{
		count=0;
		for(int j=0;j<l;j++)
		{
			if(ch[j]==ch[i])
				count++;
		}
		for(int k=0;k<l;k++)
		{
			 if(ch[k]==ch[i])
				 flag=0;
		}
		flag=0;
		hm.put(ch[i],count);
	}
	return hm;
  }
  public static void main(String[] args)
  {
	  Scanner sc=new Scanner(System.in);
	  char ch[]=new char[50];
	  System.out.println("Enter string");
	  ch=sc.next().toCharArray();
	  Ex2 obj=new Ex2();
	  HashMap<Character, Integer> hm=new HashMap<Character, Integer>();
	  hm=obj.countCharacter(ch);
	  for(Entry<Character, Integer> mp : hm.entrySet())
	  {
		  char key=(char) mp.getKey();
		  Integer count = (Integer) mp.getValue();
		  System.out.print("'"+key+"'"+":"+count+",");
	  }
	  sc.close();
  }
}
