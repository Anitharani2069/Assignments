/**
 * 
 */
package lab1;                            

import java.util.Scanner;

/**
 * @author ygudala
 *
 */
class Sum {
	int calculateSum(int n)
	{
		int sum=0;
		for(int i=0;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
				sum=sum+i;
		}
		return sum;
	}
}

public class Ex1 {
	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		Sum obj=new Sum();
		System.out.println("Calculation of sum"+ " " +obj.calculateSum(n));
		
	}
}



