package lab1;
import java.util.Scanner;
class Difference{
	int calculateDifference(int n) {
		int sum1=0,sum2 = 0,sum=0;
		int r,t=0;
		for(int i=1;i<=n;i++)
		{
			r=i*i;
			sum1=sum1+r;
				
		}
		for(int j=1;j<=n;j++)
		{
			t=j+t;
			sum2=t*t;
		}
		sum=sum2-sum1;
		return sum;
		
	}
}

public class Ex2 {
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Difference obj=new Difference();
		System.out.println("Difference"+" "+obj.calculateDifference(n));
	}

}
