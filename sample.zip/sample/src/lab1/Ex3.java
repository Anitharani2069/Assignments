package lab1;
import java.util.Scanner;
class increasingNumber {
      int n,currentNum;
      boolean checkNumber(int n)
      {
          
    	  boolean t=false;
    	  currentNum=n%10;
    	  n=n/10;
    	  while(n>0)
    	  {
    		if(currentNum>(n%10))
    		{
    			t=true;
    		}
    		else
    		{
    			t=false;
    			break;
    		}
    		currentNum=n%10;
    		n=n/10;
    	  }
		return t;
      }
}

public class Ex3 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		increasingNumber obj=new increasingNumber();
		System.out.println("Increasing Number"+" "+obj.checkNumber(n));
	}

}
