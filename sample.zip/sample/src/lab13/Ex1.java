package lab13;

import java.util.Scanner;

class Ex1 {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	int m=sc.nextInt();
	int n=sc.nextInt();
	Sum s=(x,y)->Math.pow(x,y);
	double x=s.calSum(m,n);
	System.out.println(x);	
}
}
interface Sum
{
    double calSum(double x,double y);	
}
