package lab5;
import java.util.Scanner;
class EmployeeException extends RuntimeException
{
	EmployeeException()
	{
		System.out.println("Salary should be above 3000");
	}
}
public class EX6 {
      public void main(String args[])
      {
    	  Scanner sc=new Scanner(System.in);
    	  int n=sc.nextInt();
    	  sc.close();
    	  try
    	  {
    		  if(n<3000)
    		  {
    			  throw new EmployeeException();
    		  }
    		  else
    			  System.out.println("Salary: "+n);
    	  }
    	  catch(Exception e)
    	  { 
    		  System.out.println("Exception error");
    	  }
      }
}
