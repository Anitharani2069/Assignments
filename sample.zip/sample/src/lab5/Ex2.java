package lab5;
import java.util.Scanner;
public class Ex2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		Fibonacci f=new Fibonacci();
		long res=f.input(n);
		System.out.println("Non-Recursive Function: " + res);
		int res1=f.recursive(n);
		System.out.println("Recursive function: "+res1);
	}

}
class Fibonacci
	{
	int a=1;
	int b=1;
	int c=0;
	int count;
	int input(int a)
	{
		count=a;
		count=fabo(count);
		return count;
	}
	int fabo(int count)
	{
		if(count!=2)
		{
			c=a+b;
			a=b;
			b=c;
			fabo(--count);
		}
		return c;
	}
	int recursive(int n)
	{
		int res=0;
		if(n==1)
			res=1;
		else if(n==2)
			res=1;
		else
			res=recursive((n-2)+recursive(n-1));
			return res;
	}
}
