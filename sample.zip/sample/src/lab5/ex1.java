package lab5;
enum Traffic{
	RED,GREEN,YELLOW;
}
public class ex1 {
	Traffic color;
     public ex1(Traffic color)
   {
	    this.color=color;
   }
     public void selectcolor()
     {
    	 switch(color)
    	 {
    	     case RED: 
    		 System.out.println("STOP");
    		   break;
    	     case GREEN:
    	    	 System.out.println("GO");
    	    	 break;
    	     case YELLOW: System.out.println("WAIT");
    	     break;
    	     default:
    	    	 System.out.println("READY");
    	    	  break;
    	 }
    	     
     }   	 
    	 
    	 public static void main(String args[])
    	 {
    		 ex1 e=new ex1(Traffic.GREEN);
    		 e.selectcolor();
     }

}
