package lab5;
import java.util.Scanner;
class FullNameEmployee extends Exception {
	public FullNameEmployee(String str)
	{
		System.out.println("Firstname and last name should not be blank");
	}

	
}
	
public class Ex4 {
	public static void main(String args[])
	{
		Scanner sc =new Scanner(System.in);
		String fn=null;
		String ln=null;
		sc.close();
		try
		{
			if(fn==null || ln==null)
				throw new FullNameEmployee("");
			else
				System.out.println("firstname: " +fn+ "lastname: "+ln);
		}
		catch(Exception e) 
		{
			System.out.println("Exception error");
		}
	}
}
