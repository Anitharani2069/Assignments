package lab4;
import java.util.Scanner;
class Cube
{
	public int cubes(int n)
	{
		int sum=0,rem=0,cube;
		while(n>0)
		{
			rem=n%10;
			cube=(int) Math.pow(rem, 3);
			sum=sum+cube;
			n=n/10;
		}
		return sum;
	}
}
public class ex1 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Cube cubeObj=new Cube();
		System.out.println("enter n digit number");
		int n=sc.nextInt();
		System.out.println("sum of cubes of n digit number:" + " "+cubeObj.cubes(n));
		sc.close();
		
	}
}
